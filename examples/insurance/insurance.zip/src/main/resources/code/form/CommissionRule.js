a => a.number("commissionRate")
	.manyToOne("partyId","party")
	.manyToOne("productId","product")
	.manyToOne("policyId","policy")