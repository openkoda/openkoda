flow
    .then(a => a.services.data.saveForm(a.form))
    .thenSet("redirectUrl", a => "/html/cn/tasks")