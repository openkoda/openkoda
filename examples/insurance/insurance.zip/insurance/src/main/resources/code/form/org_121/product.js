a => a.text("product")
	.text("productDescription")
    .manyToOne("partyId","party")