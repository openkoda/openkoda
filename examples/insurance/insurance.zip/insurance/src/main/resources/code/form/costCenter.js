a => a.text("name")
	.text("description")
    .number("code")
    .number("contactNumber")