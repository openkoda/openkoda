flow.thenSet("sqlSchema", a => a.services.openAI.getCompleteDataSchemaPrompt())
